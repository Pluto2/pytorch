import torch
path = './checkpoint/ckpt.pth'
pretrained_dict = torch.load(path)
pretrained_dict.acc
# for k, v in pretrained_dict.items():
#         print(k)